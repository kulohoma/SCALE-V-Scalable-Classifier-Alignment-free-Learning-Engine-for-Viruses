library(pROC)
library(MLmetrics)
library(mltools)
library(PRROC)

preds <- readRDS("test_predictions.rds")

vp <- preds$virus_probs
hp <- preds$host_probs

yv <- preds$y_test_virus
yh <- preds$y_test_host

yv_hat <- max.col(vp) - 1
yh_hat <- max.col(hp) - 1

cat("Macro F1 Virus:", mean(sapply(unique(yv), function(i)
  F1_Score(as.integer(yv==i), as.integer(yv_hat==i))
)), "\n")

cat("Macro F1 Host:", mean(sapply(unique(yh), function(i)
  F1_Score(as.integer(yh==i), as.integer(yh_hat==i))
)), "\n")

cat("MCC Virus:", mcc(as.factor(yv_hat), as.factor(yv)), "\n")
cat("MCC Host:", mcc(as.factor(yh_hat), as.factor(yh)), "\n")
