
library(rentrez)
library(Biostrings)
library(tidyverse)
library(xml2)

set.seed(42)


# Configuration


# Put your NCBI API key in an environment variable
NCBI_API_KEY <- Sys.getenv("NCBI_API_KEY")
if (nzchar(NCBI_API_KEY)) set_entrez_key(NCBI_API_KEY)

TEST_MODE <- FALSE   # if TRUE, caps target_pass_qc at TEST_TARGET
TEST_TARGET <- 5

MIN_SEQ_LEN    <- 200
MAX_SEQ_LEN    <- 100000
MAX_AMBIG_FRAC <- 0.05

EFETCH_BATCH  <- 200    # UIDs per esearch/efetch page
SLEEP_BETWEEN <- ifelse(nzchar(NCBI_API_KEY), 0.11, 0.34) 

SAFETY_EXAMINED_MULTIPLIER <- 20
SAFETY_ABSOLUTE_CEILING    <- 8000

HELD_OUT_FAMILIES <- c(
  "Nairoviridae", "Phenuiviridae", "Artoviridae", "Picobirnaviridae",
  "Nodaviridae", "Virgaviridae", "Betaflexiviridae", "Asfarviridae"
)

dir.create("output", showWarnings = FALSE)
dir.create("logs", showWarnings = FALSE)

log_message <- function(...) {
  msg <- paste0(...)
  cat(msg, "\n")
  write(paste(Sys.time(), "-", msg), file = "logs/pipeline.log", append = TRUE)
}


# ICTV family validation 


ictv <- read_csv("1.ictv_family_lookup.csv", show_col_types = FALSE)

legacy_family_aliases <- tibble(
  legacy_family = c("Reoviridae", "Reoviridae", "Herpesviridae"),
  ictv_family   = c("Sedoreoviridae", "Spinareoviridae", "Orthoherpesviridae")
)

genus_to_family <- ictv %>%
  filter(!is.na(Genus)) %>%
  distinct(Genus, Family)

validate_family <- function(target_family, organism, lineage) {
  modern_targets <- c(
    target_family,
    legacy_family_aliases$ictv_family[legacy_family_aliases$legacy_family == target_family]
  )
  if (any(str_detect(lineage, fixed(modern_targets)))) return(TRUE)
  genus_guess <- str_extract(organism, "^[A-Za-z0-9]+")
  hit <- genus_to_family %>% filter(Genus == genus_guess)
  if (nrow(hit) > 0 && any(hit$Family %in% modern_targets)) return(TRUE)
  FALSE
}


discovery_table <- tribble(
  ~family,             ~host_species,          ~host_class,
  "Orthomyxoviridae",  "Homo sapiens",         "human",
  "Orthomyxoviridae",  "Gallus gallus",        "bird",
  "Orthomyxoviridae",  "Anas platyrhynchos",   "bird",
  "Orthomyxoviridae",  "Sus scrofa",           "domestic",
  "Coronaviridae",     "Homo sapiens",         "human",
  "Coronaviridae",     "Rhinolophus",          "bat",
  "Coronaviridae",     "Camelus dromedarius",  "domestic",
  "Coronaviridae",     "Felis catus",          "domestic",
  "Retroviridae",      "Homo sapiens",         "human",
  "Retroviridae",      "Pan troglodytes",      "nhp",
  "Retroviridae",      "Macaca",               "nhp",
  "Retroviridae",      "Mus musculus",         "rodent",
  "Filoviridae",       "Homo sapiens",         "human",
  "Filoviridae",       "Pteropus",             "bat",
  "Rhabdoviridae",     "Canis lupus",          "domestic",
  "Rhabdoviridae",     "Chiroptera",           "bat",
  "Flaviviridae",      "Aedes aegypti",        "insect",
  "Flaviviridae",      "Culex",                "insect",
  "Flaviviridae",      "Homo sapiens",         "human",
  "Flaviviridae",      "Ixodes",               "insect",
  "Flaviviridae",      "Macaca",               "nhp",
  "Togaviridae",       "Homo sapiens",         "human",
  "Togaviridae",       "Aedes aegypti",        "insect",
  "Paramyxoviridae",   "Homo sapiens",         "human",
  "Paramyxoviridae",   "Pteropus",             "bat",
  "Paramyxoviridae",   "Gallus gallus",        "bird",
  "Poxviridae",        "Homo sapiens",         "human",
  "Poxviridae",        "Rodentia",             "rodent",
  "Poxviridae",        "Gallus gallus",        "bird",
  "Poxviridae",        "Macaca",               "nhp",
  "Orthoherpesviridae","Homo sapiens",         "human",
  "Orthoherpesviridae","Equus caballus",       "domestic",
  "Orthoherpesviridae","Mus musculus",         "rodent",
  "Orthoherpesviridae","Macaca",               "nhp",
  "Adenoviridae",      "Homo sapiens",         "human",
  "Adenoviridae",      "Gallus gallus",        "bird",
  "Adenoviridae",      "Pteropus",             "bat",
  "Picornaviridae",    "Homo sapiens",         "human",
  "Picornaviridae",    "Bos taurus",           "domestic",
  "Picornaviridae",    "Chiroptera",           "bat",
  "Picornaviridae",    "Mus musculus",         "rodent",
  "Arenaviridae",      "Mastomys natalensis",  "rodent",
  "Arenaviridae",      "Homo sapiens",         "human",
  "Arenaviridae",      "Calomys",              "rodent",
  "Hantaviridae",      "Apodemus",             "rodent",
  "Hantaviridae",      "Peromyscus",           "rodent",
  "Nairoviridae",      "Hyalomma",             "insect",
  "Nairoviridae",      "Homo sapiens",         "human",
  "Phenuiviridae",     "Ovis aries",           "domestic",
  "Phenuiviridae",     "Phlebotomus",          "insect",
  "Nodaviridae",       "Drosophila",           "insect",
  "Nodaviridae",       "Culex",                "insect",
  "Asfarviridae",      "Sus scrofa",           "domestic",
  "Asfarviridae",      "Ornithodoros",         "insect",
  "Reoviridae",        "Homo sapiens",         "human",
  "Reoviridae",        "Bos taurus",           "domestic",
  "Reoviridae",        "Culicoides",           "insect",
  "Hepadnaviridae",    "Homo sapiens",         "human",
  "Hepadnaviridae",    "Anas platyrhynchos",   "bird",
  "Papillomaviridae",  "Homo sapiens",         "human",
  "Papillomaviridae",  "Bos taurus",           "domestic",
  "Parvoviridae",      "Homo sapiens",         "human",
  "Parvoviridae",      "Canis lupus",          "domestic",
  "Parvoviridae",      "Chiroptera",           "bat",
  "Virgaviridae",      "Solanum lycopersicum", "env_plant",
  "Virgaviridae",      "Nicotiana tabacum",    "env_plant",
  "Betaflexiviridae",  "Malus domestica",      "env_plant",
  "Betaflexiviridae",  "Vitis vinifera",       "env_plant",
  "Artoviridae",       "Chiroptera",           "bat",
  "Picobirnaviridae",  "Homo sapiens",         "human",

  "Hepeviridae",       "Rattus norvegicus",    "rodent",
  "Hepeviridae",       "Rousettus",            "bat",
  "Hepeviridae",       "Macaca",               "nhp",
  "Hepeviridae",       "Oryctolagus cuniculus","other_mammal",
  "Caliciviridae",     "Mus musculus",         "rodent",
  "Caliciviridae",     "Oryctolagus cuniculus","other_mammal",
  "Astroviridae",      "Miniopterus",          "bat",
  "Astroviridae",      "Mus musculus",         "rodent",
  "Astroviridae",      "Mustela",              "other_mammal",
  "Circoviridae",      "Rousettus",            "bat",
  "Circoviridae",      "Macaca",               "nhp",
  "Geminiviridae",     "Solanum lycopersicum", "env_plant",
  "Geminiviridae",     "Nicotiana tabacum",    "env_plant",
  "Potyviridae",       "Solanum tuberosum",    "env_plant",
  "Potyviridae",       "Nicotiana tabacum",    "env_plant",
  "Bromoviridae",      "Cucumis sativus",      "env_plant",
  "Closteroviridae",   "Vitis vinifera",       "env_plant",
)

cat(sprintf("Discovery table: %d (family, host) combinations\n\n", nrow(discovery_table)))


# inclusion criteria

host_class_targets <- tribble(
  ~host_class,     ~target_pass_qc,
  "human",         120,
  "bird",          120,
  "domestic",      120,
  "insect",        120,
  "bat",           350,
  "rodent",        350,
  "nhp",           350,
  "other_mammal",  350,
  "env_plant",     350,
)

target_for <- function(host_class) {
  t <- host_class_targets$target_pass_qc[host_class_targets$host_class == host_class]
  t <- if (length(t) == 0) 120 else t[1]
  if (TEST_MODE) min(t, TEST_TARGET) else t
}



safe_search <- function(term, retmax, retstart = 0) {
  tryCatch(
    entrez_search(db = "nuccore", term = term, retmax = retmax, retstart = retstart),
    error = function(e) NULL
  )
}

fetch_batch <- function(uids) {
  xml_txt <- tryCatch(
    entrez_fetch(db = "nuccore", id = uids, rettype = "gb", retmode = "xml"),
    error = function(e) NULL
  )
  Sys.sleep(SLEEP_BETWEEN)
  if (is.null(xml_txt)) return(NULL)
  read_xml(xml_txt)
}

parse_gbseq <- function(node) {
  accession <- xml_text(xml_find_first(node, ".//GBSeq_primary-accession"))
  organism  <- xml_text(xml_find_first(node, ".//GBSeq_organism"))
  lineage   <- xml_text(xml_find_first(node, ".//GBSeq_taxonomy"))
  seq       <- xml_text(xml_find_first(node, ".//GBSeq_sequence"))
  list(accession = accession, organism = organism, lineage = lineage, seq = toupper(seq))
}

ambig_fraction <- function(seq) 1 - str_count(seq, "[ACGT]") / nchar(seq)


retrieve_adaptive <- function(term, family_label, host_class_label,
                               target_pass_qc, virus_name_override = NULL) {

  safety_cap <- min(target_pass_qc * SAFETY_EXAMINED_MULTIPLIER, SAFETY_ABSOLUTE_CEILING)

  count_res <- safe_search(term, retmax = 0)
  Sys.sleep(SLEEP_BETWEEN)
  available <- if (is.null(count_res)) 0L else count_res$count

  qc_rows  <- list()
  seq_rows <- list()
  examined <- 0L
  passed   <- 0L
  offset   <- 0L
  stopped  <- "no_results"

  if (available == 0) {
    return(list(available = 0L, examined = 0L, passed = 0L,
                qc_rows = qc_rows, seq_rows = seq_rows, stopped = stopped))
  }

  repeat {
    if (passed >= target_pass_qc) { stopped <- "target_reached"; break }
    if (offset >= available)      { stopped <- "exhausted";      break }
    if (examined >= safety_cap)   { stopped <- "safety_cap";     break }

    page_retmax <- max(1, min(EFETCH_BATCH, available - offset, safety_cap - examined))
    res <- safe_search(term, retmax = page_retmax, retstart = offset)
    Sys.sleep(SLEEP_BETWEEN)

    if (is.null(res) || length(res$ids) == 0) { stopped <- "search_failed"; break }
    offset <- offset + length(res$ids)

    doc <- fetch_batch(res$ids)
    if (is.null(doc)) next   # offset already advanced; try the next page

    gbseqs <- xml_find_all(doc, "//GBSeq")

    for (node in gbseqs) {
      examined <- examined + 1L
      rec <- parse_gbseq(node)
      if (is.na(rec$seq) || nchar(rec$seq) == 0) next

      seq_len    <- nchar(rec$seq)
      frac_ambig <- ambig_fraction(rec$seq)
      pass_len   <- seq_len >= MIN_SEQ_LEN && seq_len <= MAX_SEQ_LEN
      pass_ambig <- frac_ambig <= MAX_AMBIG_FRAC
      pass_fam   <- validate_family(family_label, rec$organism, rec$lineage)
      pass_all   <- pass_len && pass_ambig && pass_fam

      qc_rows[[length(qc_rows) + 1]] <- tibble(
        accession = rec$accession, family = family_label, host_class = host_class_label,
        length = seq_len, ambig_frac = frac_ambig,
        pass_len = pass_len, pass_ambig = pass_ambig, pass_family = pass_fam,
        pass_all = pass_all
      )

      if (pass_all) {
        passed <- passed + 1L
        seq_rows[[length(seq_rows) + 1]] <- tibble(
          seq_id = rec$accession, virus_class = family_label, host_class = host_class_label,
          virus_name = if (!is.null(virus_name_override)) virus_name_override else rec$organism,
          sequence = rec$seq
        )
      }
      if (passed >= target_pass_qc) break   # stop mid-batch as soon as we have enough
    }
  }

  list(available = available, examined = examined, passed = passed,
       qc_rows = qc_rows, seq_rows = seq_rows, stopped = stopped)
}



all_qc_rows  <- list()
all_seq_rows <- list()
retrieval_log_rows <- list()

for (i in seq_len(nrow(discovery_table))) {
  fam  <- discovery_table$family[i]
  host <- discovery_table$host_species[i]
  cls  <- discovery_table$host_class[i]
  tgt  <- target_for(cls)

  term <- sprintf('"%s"[Organism] AND "%s"[Host] AND %d:%d[SLEN]',
                   fam, host, MIN_SEQ_LEN, MAX_SEQ_LEN)

  cat(sprintf("[%d/%d] %-20s host=%-24s class=%-13s target_pass_qc=%d\n",
              i, nrow(discovery_table), fam, host, cls, tgt))

  result <- retrieve_adaptive(term, fam, cls, tgt)

  cat(sprintf("  available=%d examined=%d passed=%d (%s)\n",
              result$available, result$examined, result$passed, result$stopped))

  retrieval_log_rows[[length(retrieval_log_rows) + 1]] <- tibble(
    family = fam, host_species = host, host_class = cls,
    target_pass_qc = tgt, available = result$available,
    examined = result$examined, passed_qc = result$passed, stopped = result$stopped
  )

  all_qc_rows  <- c(all_qc_rows,  result$qc_rows)
  all_seq_rows <- c(all_seq_rows, result$seq_rows)
}

qc_report <- bind_rows(all_qc_rows) %>% distinct(accession, family, .keep_all = TRUE)
write_csv(qc_report, "output/qc_report.csv")

main_seqs <- bind_rows(all_seq_rows) %>% distinct(seq_id, virus_class, .keep_all = TRUE)
cat(sprintf("\nSequences passing QC (main loop): %d\n\n", nrow(main_seqs)))


# influenza retrieval


flu_targets <- tribble(
  ~virus_name,          ~host_class,      ~host_species,          ~target_pass_qc,
  "Influenza A virus",  "bird",           "Gallus gallus",        400,
  "Influenza A virus",  "domestic",       "Sus scrofa",           400,
  "Influenza D virus",  "domestic",       "Bos taurus",           150,
  "Influenza A virus",  "human",          "Homo sapiens",         300,
  "Influenza B virus",  "human",          "Homo sapiens",         300,
  "Influenza C virus",  "human",          "Homo sapiens",         150,
  "Influenza A virus",  "other_mammal",   "Equus caballus",       250,
)

flu_qc_rows  <- list()
flu_seq_rows <- list()

for (i in seq_len(nrow(flu_targets))) {
  vn   <- flu_targets$virus_name[i]
  cls  <- flu_targets$host_class[i]
  host <- flu_targets$host_species[i]
  tgt  <- if (TEST_MODE) min(TEST_TARGET, flu_targets$target_pass_qc[i]) else flu_targets$target_pass_qc[i]

  term <- sprintf('"%s"[Organism] AND "%s"[Host] AND %d:%d[SLEN]',
                   vn, host, MIN_SEQ_LEN, MAX_SEQ_LEN)

  cat(sprintf("[flu %d/%d] %-20s host=%-20s target_pass_qc=%d\n",
              i, nrow(flu_targets), vn, host, tgt))

  result <- retrieve_adaptive(term, "Orthomyxoviridae", cls, tgt, virus_name_override = vn)

  cat(sprintf("  available=%d examined=%d passed=%d (%s)\n",
              result$available, result$examined, result$passed, result$stopped))

  retrieval_log_rows[[length(retrieval_log_rows) + 1]] <- tibble(
    family = "Orthomyxoviridae", host_species = host, host_class = cls,
    target_pass_qc = tgt, available = result$available,
    examined = result$examined, passed_qc = result$passed, stopped = result$stopped
  )

  flu_qc_rows  <- c(flu_qc_rows,  result$qc_rows)
  flu_seq_rows <- c(flu_seq_rows, result$seq_rows)
}

flu_seqs <- bind_rows(flu_seq_rows) %>% distinct(seq_id, .keep_all = TRUE)
cat(sprintf("\nInfluenza sequences retrieved: %d\n", nrow(flu_seqs)))
writeXStringSet(
  DNAStringSet(setNames(flu_seqs$sequence, flu_seqs$seq_id)),
  "flu_sequences.fasta"
)

qc_report_flu <- bind_rows(flu_qc_rows)
write_csv(bind_rows(qc_report, qc_report_flu) %>% distinct(accession, family, .keep_all = TRUE),
          "output/qc_report.csv")

retrieval_log <- bind_rows(retrieval_log_rows)
write_csv(retrieval_log, "output/retrieval_summary.csv")

cat("\nRetrieval summary (available / examined / passed_qc per combination):\n")
print(retrieval_log %>% arrange(host_class, desc(passed_qc)))




all_seqs <- bind_rows(main_seqs, flu_seqs) %>% distinct(seq_id, .keep_all = TRUE)

crossfamily <- all_seqs %>% filter(virus_class %in% HELD_OUT_FAMILIES)
splittable  <- all_seqs %>% filter(!virus_class %in% HELD_OUT_FAMILIES)

cat(sprintf("Cross-family holdout panel: %d sequences across %d families (full holdout)\n",
            nrow(crossfamily), n_distinct(crossfamily$virus_class)))

held_out_queries <- splittable %>%
  group_by(host_class) %>%
  slice_sample(n = 1) %>%
  ungroup()

splittable <- anti_join(splittable, held_out_queries, by = "seq_id")

set.seed(42)
splittable <- splittable %>%
  group_by(virus_class, host_class) %>%
  mutate(
    rank_in_group = sample(seq_len(n())),
    frac = rank_in_group / n(),
    partition = case_when(
      frac <= 0.8  ~ "train",
      frac <= 0.9  ~ "val",
      TRUE         ~ "test"
    )
  ) %>%
  ungroup() %>%
  select(-rank_in_group, -frac)

crossfamily      <- crossfamily      %>% mutate(partition = "crossfamily")
held_out_queries <- held_out_queries %>% mutate(partition = "held_out_query")

all_metadata <- bind_rows(splittable, crossfamily, held_out_queries)


print(all_metadata %>% count(partition))
cat("\nBy host class (train/val/test only):\n")
print(splittable %>% count(host_class, sort = TRUE))
cat("\nBy viral family (train/val/test only):\n")
print(splittable %>% count(virus_class, sort = TRUE))

write_fasta <- function(df, path) {
  if (nrow(df) == 0) { file.create(path); return(invisible()) }
  headers <- sprintf("%s|%s|%s|%s", df$seq_id, df$virus_class, df$host_class, df$virus_name)
  ss <- DNAStringSet(setNames(df$sequence, headers))
  writeXStringSet(ss, path)
}

write_fasta(filter(all_metadata, partition == "train"), "output/train.fasta")
write_fasta(filter(all_metadata, partition == "val"),   "output/val.fasta")
write_fasta(filter(all_metadata, partition == "test"),  "output/test.fasta")
write_fasta(crossfamily,       "output/crossfamily_panel.fasta")
write_fasta(held_out_queries,  "output/held_out_queries.fasta")

write_csv(all_metadata %>% select(seq_id, virus_class, host_class, partition),
          "output/all_metadata.csv")

write_csv(
  all_metadata %>%
    filter(partition %in% c("train", "val", "test")) %>%
    select(seq_id, virus_class, host_class, partition),
  "metadata.csv"
)

cat("\nPipeline complete. Output files in ./output/\n")
cat("File manifest:\n")
cat("  output/train.fasta              - Training sequences\n")
cat("  output/val.fasta                - Validation sequences\n")
cat("  output/test.fasta               - Test sequences\n")
cat("  output/crossfamily_panel.fasta  - Fully held-out families (generalization)\n")
cat("  output/held_out_queries.fasta   - One query per host class (evaluation)\n")
cat("  output/all_metadata.csv         - Full metadata (all partitions)\n")
cat("  output/qc_report.csv            - QC filter results\n")
cat("  output/retrieval_summary.csv    - available / examined / passed_qc per query\n")
cat("  flu_sequences.fasta             - Influenza sequences\n")
cat("  metadata.csv                    - ML pipeline input (train/val/test only)\n")
