reticulate::use_virtualenv("r-keras", required = TRUE)
library(keras)
library(tensorflow)
library(reticulate)
library(readr)
library(dplyr)

py_require(c("tensorflow", "numpy"))


encoded  <- readRDS("encoded_sequences.rds")
metadata <- read_csv("metadata.csv", show_col_types = FALSE)
vocab    <- readRDS("kmer_vocab.rds")

train_idx <- as.integer(encoded$train_idx)
val_idx   <- as.integer(encoded$val_idx)
test_idx  <- as.integer(encoded$test_idx)


virus_levels <- sort(unique(metadata$virus_class))
host_levels  <- sort(unique(metadata$host_class))

virus_map <- setNames(seq_along(virus_levels) - 1L, virus_levels)
host_map  <- setNames(seq_along(host_levels)  - 1L, host_levels)

virus_labels <- as.integer(unname(virus_map[as.character(metadata$virus_class)]))
host_labels  <- as.integer(unname(host_map[as.character(metadata$host_class)]))

stopifnot(!any(is.na(virus_labels)))
stopifnot(!any(is.na(host_labels)))


maxlen <- 1024L

pad_seq <- function(x) {
  x   <- as.integer(x)
  x   <- head(x, maxlen)
  out <- rep(0L, maxlen)
  out[seq_along(x)] <- x
  out
}

to_matrix <- function(seqs) {
  mat <- do.call(rbind, lapply(seqs, pad_seq))
  storage.mode(mat) <- "integer"
  mat
}

X_train <- to_matrix(encoded$train)
X_val   <- to_matrix(encoded$val)
X_test  <- to_matrix(encoded$test)


np <- import("numpy", convert = FALSE)
py <- import_builtins()

to_np_int <- function(x) {
  x <- as.matrix(x)
  storage.mode(x) <- "integer"
  np$array(x, dtype = "int32")
}

X_train <- to_np_int(X_train)
X_val   <- to_np_int(X_val)
X_test  <- to_np_int(X_test)

y_train_virus <- np$array(as.integer(virus_labels[train_idx]), dtype = "int32")
y_val_virus   <- np$array(as.integer(virus_labels[val_idx]),   dtype = "int32")
y_test_virus  <- np$array(as.integer(virus_labels[test_idx]),  dtype = "int32")

y_train_host  <- np$array(as.integer(host_labels[train_idx]),  dtype = "int32")
y_val_host    <- np$array(as.integer(host_labels[val_idx]),    dtype = "int32")
y_test_host   <- np$array(as.integer(host_labels[test_idx]),   dtype = "int32")


inputs <- layer_input(shape = c(maxlen), dtype = "int32")

x <- inputs %>%
  layer_embedding(
    input_dim  = length(vocab) + 1L,
    output_dim = 128L
  ) %>%
  layer_global_average_pooling_1d()

shared <- x %>%
  layer_dense(128L, activation = "relu") %>%
  layer_dropout(0.3)

virus_out <- shared %>%
  layer_dense(length(virus_levels), activation = "softmax", name = "virus")

host_out <- shared %>%
  layer_dense(length(host_levels), activation = "softmax", name = "host")

model <- keras_model(inputs, list(virus_out, host_out))


model$compile(
  optimizer = "adam",
  loss = list(
    virus = "sparse_categorical_crossentropy",
    host  = "sparse_categorical_crossentropy"
  ),
  metrics = list(
    virus = "accuracy",
    host  = "accuracy"
  )
)

summary(model)


history <- model$fit(
  X_train,
  list(virus = y_train_virus, host = y_train_host),
  validation_data = list(
    X_val,
    list(virus = y_val_virus, host = y_val_host)
  ),
  epochs     = py$int(50L), # from 10L
  batch_size = py$int(32L)  # from 8L
)


preds <- model$predict(X_test)


saveRDS(list(
  virus_probs  = preds[[1]],
  host_probs   = preds[[2]],
  y_test_virus = as.integer(virus_labels[test_idx]),
  y_test_host  = as.integer(host_labels[test_idx]),
  virus_levels = virus_levels,
  host_levels  = host_levels
), "test_predictions.rds")

saveRDS(list(
  virus_map    = virus_map,
  host_map     = host_map,
  virus_levels = virus_levels,
  host_levels  = host_levels
), "label_encoders.rds")

model$save("transformer_model_multitask.keras")
