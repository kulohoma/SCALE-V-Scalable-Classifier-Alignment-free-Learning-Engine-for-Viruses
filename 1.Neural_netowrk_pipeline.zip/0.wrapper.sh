for f in 1.retrieve_sequences.R 2.preprocess_and_tokenize.R 3.train_model.R 4.predict_model.R 5.visualize_AUROC_curve.R 6.evaluate_model.R ; do Rscript $f; done



