library(keras)
library(Biostrings)
library(tidyverse)
library(reticulate)

model <- load_model_tf("transformer_model_multitask.keras")
enc <- readRDS("label_encoders.rds")
vocab <- readRDS("kmer_vocab.rds")

virus_levels <- enc$virus_levels
host_levels  <- enc$host_levels

query <- readDNAStringSet("query.fasta")

k <- 7
maxlen <- 1024

tokenize <- function(seq,k=7){
  if (nchar(seq)<k) return(integer(0))
  sapply(1:(nchar(seq)-k+1), function(i) substr(seq,i,i+k-1))
}

encode <- function(seq){
  km <- tokenize(seq,k)
  ids <- vocab[km]
  ids[is.na(ids)] <- 0
  ids
}

pad <- function(x){
  x <- head(x,maxlen)
  c(x, rep(0,maxlen-length(x)))
}

X <- t(sapply(as.character(query), function(s) pad(encode(s))))

np <- import("numpy", convert=FALSE)
X <- np$array(X, dtype="int32")

pred <- model$predict(X)

virus <- apply(pred[[1]],1,which.max)-1
host  <- apply(pred[[2]],1,which.max)-1

tibble(
  id=names(query),
  virus=virus_levels[virus+1],
  host=host_levels[host+1]
)