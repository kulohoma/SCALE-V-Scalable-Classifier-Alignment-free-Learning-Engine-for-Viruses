library(pROC)

preds        <- readRDS("test_predictions.rds")
virus_probs  <- preds$virus_probs
host_probs   <- preds$host_probs
yv           <- preds$y_test_virus
yh           <- preds$y_test_host
virus_levels <- preds$virus_levels
host_levels  <- preds$host_levels


make_palette <- function(n) {
  hcl.colors(n, palette = "Dark 3", alpha = 0.85)
}


compute_rocs <- function(probs, y, levels) {
  lapply(seq_along(levels), function(i) {
    bin <- as.numeric(y == (i - 1))
    if (length(unique(bin)) < 2) return(NULL)
    roc(bin, probs[, i], quiet = TRUE)
  })
}


plot_roc <- function(probs, y, levels, title) {
  rocs <- compute_rocs(probs, y, levels)
  cols <- make_palette(length(levels))


  auc_vals <- sapply(rocs, function(r) if (is.null(r)) NA else round(auc(r), 3))
  legend_labels <- ifelse(
    is.na(auc_vals),
    paste0(levels, " (n/a)"),
    paste0(levels, "  [", auc_vals, "]")
  )

  plot(0, 0, type = "n", xlim = c(0, 1), ylim = c(0, 1),
       xlab = "False Positive Rate", ylab = "True Positive Rate",
       main = title, font.main = 2, cex.main = 1.1,
       xaxs = "i", yaxs = "i", las = 1)

  abline(0, 1, lty = 2, col = "grey60", lwd = 1)   # chance line
  grid(col = "grey90", lty = 1)

  for (i in seq_along(rocs)) {
    r <- rocs[[i]]
    if (is.null(r)) next
    lines(1 - r$specificities, r$sensitivities,
          col = cols[i], lwd = 1.8)
  }

  legend("bottomright",
         legend  = legend_labels,
         col     = cols,
         lwd     = 2,
         cex     = 0.62,
         bg      = adjustcolor("white", alpha.f = 0.85),
         box.lty = 1,
         title   = "Class  [AUC]",
         title.font = 2)
}

pdf("roc.pdf", width = 16, height = 7.5, useDingbats = FALSE)

par(
  mfrow   = c(1, 2),
  mar     = c(4.5, 4.5, 3, 1),
  oma     = c(0, 0, 2, 0),
  family  = "sans"
)

plot_roc(virus_probs, yv, virus_levels, "Virus Family — One-vs-Rest ROC")
plot_roc(host_probs,  yh, host_levels,  "Host Type — One-vs-Rest ROC")

mtext("Multi-class ROC Curves", outer = TRUE, cex = 1.3, font = 2, line = 0.5)

dev.off()
