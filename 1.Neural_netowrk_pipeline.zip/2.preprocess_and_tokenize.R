library(tidyverse)
library(Biostrings)

metadata <- read_csv("metadata.csv", show_col_types = FALSE)

# Keep only train/val/test rows for the model

metadata <- metadata %>%
  filter(partition %in% c("train", "val", "test")) %>%
  arrange(seq_id)

cat(sprintf("Metadata loaded: %d sequences (train/val/test)\n", nrow(metadata)))

virus_levels <- sort(unique(metadata$virus_class))
host_levels  <- sort(unique(metadata$host_class))

virus_map <- setNames(seq_along(virus_levels) - 1L, virus_levels)
host_map  <- setNames(seq_along(host_levels)  - 1L, host_levels)

metadata$virus_id <- virus_map[metadata$virus_class]
metadata$host_id  <- host_map[metadata$host_class]


load_fasta_partition <- function(path) {
  if (!file.exists(path)) {
    warning(sprintf("FASTA not found: %s", path))
    return(DNAStringSet())
  }
  seqs <- readDNAStringSet(path)
  names(seqs) <- sub("\\|.*", "", names(seqs))
  seqs
}

cat("Loading FASTA partitions ...\n")
seqs_train <- load_fasta_partition(file.path("output", "train.fasta"))
seqs_val   <- load_fasta_partition(file.path("output", "val.fasta"))
seqs_test  <- load_fasta_partition(file.path("output", "test.fasta"))

cat(sprintf("  train.fasta: %d seqs\n", length(seqs_train)))
cat(sprintf("  val.fasta:   %d seqs\n", length(seqs_val)))
cat(sprintf("  test.fasta:  %d seqs\n", length(seqs_test)))

all_seqs_dna <- c(seqs_train, seqs_val, seqs_test)

metadata <- metadata %>%
  filter(seq_id %in% names(all_seqs_dna))

cat(sprintf("After sequence alignment: %d metadata rows\n\n", nrow(metadata)))

if (nrow(metadata) == 0) {
  stop("No sequences matched metadata. Check that output/train|val|test.fasta exist.")
}

sequences_char <- as.character(all_seqs_dna[metadata$seq_id])

k <- 7

tokenize <- function(seq, k = 7) {
  if (nchar(seq) < k) return(character(0))
  sapply(1:(nchar(seq) - k + 1), function(i) substr(seq, i, i + k - 1))
}

train_seqs_char <- sequences_char[metadata$partition == "train"]
cat(sprintf("Building vocab from %d training sequences ...\n", length(train_seqs_char)))

all_kmers <- unlist(lapply(train_seqs_char, tokenize, k = k))
vocab     <- unique(all_kmers)
vocab     <- setNames(seq_along(vocab), vocab)   # kmer → integer id (1-based)

cat(sprintf("Vocab size: %d unique %d-mers\n\n", length(vocab), k))

encode_seq <- function(seq) {
  kmers <- tokenize(seq, k)
  if (length(kmers) == 0) return(integer(0))
  ids <- vocab[kmers]
  ids[is.na(ids)] <- 0L
  as.integer(ids)
}

cat("Encoding sequences ...\n")
encoded_sequences <- lapply(sequences_char, encode_seq)

train_idx <- which(metadata$partition == "train")
val_idx   <- which(metadata$partition == "val")
test_idx  <- which(metadata$partition == "test")

cat(sprintf("Partition sizes — train: %d  val: %d  test: %d\n\n",
            length(train_idx), length(val_idx), length(test_idx)))

if (length(train_idx) == 0) stop("No training sequences found.")
if (length(val_idx)   == 0) stop("No validation sequences found.")
if (length(test_idx)  == 0) stop("No test sequences found.")

saveRDS(list(
  train      = encoded_sequences[train_idx],
  val        = encoded_sequences[val_idx],
  test       = encoded_sequences[test_idx],
  train_idx  = train_idx,
  val_idx    = val_idx,
  test_idx   = test_idx,
  virus_labels = metadata$virus_id,
  host_labels  = metadata$host_id
), "encoded_sequences.rds")

saveRDS(vocab, "kmer_vocab.rds")

saveRDS(list(
  virus_levels = virus_levels,
  host_levels  = host_levels,
  virus_map    = virus_map,
  host_map     = host_map
), "label_encoders.rds")

saveRDS(metadata, "metadata_ordered.rds")

cat("Saved: encoded_sequences.rds\n")
cat("Saved: kmer_vocab.rds\n")
cat("Saved: label_encoders.rds\n")
cat("Saved: metadata_ordered.rds\n")
cat("\nPreprocessing complete.\n")
